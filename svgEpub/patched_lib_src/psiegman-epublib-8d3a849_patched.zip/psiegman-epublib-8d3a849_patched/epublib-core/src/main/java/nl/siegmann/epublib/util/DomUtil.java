package nl.siegmann.epublib.util;

import org.w3c.dom.Node;

public class DomUtil {

	public static void getFirstChildWithTagname(String tagname, Node parentNode) {
	}
}
